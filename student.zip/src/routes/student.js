const express = require('express');
const mongoose = require('mongoose');
const {body, validationResult} = require('express-validator')
const app = express.Router();


const Student = require('../model/student');
const studentRouter = require('../routes/student');
const cors = require('cors');
app.use(cors());


app.get("/", async (req, res) => {
    try {
       const allStudents = await Student.find({});
       res.send(allStudents)
    }catch (error){
       console.log("Error",error);
       res.status(500).send('Error getting student');
    }
});

// app.get("/", async (req, res) => {
//     try {
//        const allStudents = await Student.find({});
//        res.send(allStudents)
//     }catch (error){
//        console.log("Error",error);
//        res.status(500).send('Error getting student');
//     }
// });



app.get("/:id", async (req, res) => {
 const id = req.params.id;
 try{
    const student = await Student.findById(id);
    if (student) {
        res.send(student);
    }else{
        res.status(404).send('Student not found');
    }
 }catch(error) {
    console.log("ERROR", error);
    res.status(500).send('Error getting student');
 }
});



app.post("/", 
body('full_name')
   .isString()
   .isLength({min:4, max: 20})
   .withMessage('Value for name is not valid'),

   
body('age')
   .isInt({min:18, max:40})
   .withMessage('Age should be between 18-40'),


body('final_score')
   .isInt({min:0, max:100})  
   .withMessage('Score should be between 0 and 100'),

async (req, res) => {
    const errors = validationResult(req);
    if(!errors.isEmpty()) {
       return res.status(400).send(errors);
    }

    const student = new Student(req.body);
    try{
        const newStudent = await student.save()
        res.send(newStudent);
    }catch(error){
        console.log("Error",error);
        res.status(500).send('Error creating student');
    }
    
});



app.put("/:id",async (req, res) => {
    const id =req.params.id;
    if(!mongoose.Types.ObjectId.isValid(id)) {
        res.status(400).send('Invalid ID');
    }
    try {
        const student = await Student.findByIdAndUpdate(id, req.body, { new:true});
        console.log(student);
        res.send(student);
    } catch (error) {
        console.log('ERROR',error);
        res.status(500).send('Error updating student');
    } 
 });



app.delete("/:id", async (req, res) => {
    const id = req.params.id;
    if(!mongoose.Types.ObjectId.isValid(id)) {
        res.status(400).send('Invalid ID');
    }
    try {
        const deletedStudent = await Student.findByIdAndDelete(id);
        if (deletedStudent) {
            res.send('Student Deleted');
        }else{
            res.status(404).send('Student not found');
        }
    } catch (error) {
        console.log('ERROR',error);
        res.status(500).send('Error deleting student');
    } 
});
module.exports = app;